// +build pprof

package main

import _ "net/http/pprof"
