/*
Go Grid Router (aka ggr) is a lightweight active load balancer used to create scalable and highly-available Selenium clusters. Documentation has moved to: http://github.com/aerokube/ggr
*/
package main
