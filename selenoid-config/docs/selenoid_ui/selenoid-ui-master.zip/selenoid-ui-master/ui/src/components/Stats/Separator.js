import styled from "styled-components/macro";

const Separator = styled.div`
    height: 60px;
    border-left: 1px dashed #555f6a;
`;

export default Separator;
