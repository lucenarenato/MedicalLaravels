import React from "react";

import Viewport from "./containers/Viewport";

const App = () => {
    return <Viewport />;
};

export default App;
