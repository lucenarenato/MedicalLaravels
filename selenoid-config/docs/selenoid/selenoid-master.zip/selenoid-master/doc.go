/*
Selenoid is a powerful implementation of Selenium Hub using Docker or standalone web driver binaries to start and launch browsers. Documentation has moved to: http://github.com/aandryashin/selenoid
*/
package main
