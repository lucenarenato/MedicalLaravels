package main

import (
	"github.com/aerokube/cm/cmd"
)

func main() {
	cmd.Execute()
}
